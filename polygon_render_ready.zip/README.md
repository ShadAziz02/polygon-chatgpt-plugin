# Polygon GPT Plugin (Render Ready)

## 🚀 How to Deploy on Render

1. Go to https://render.com
2. Create a new Web Service
3. Connect to this repo or upload
4. Set build/start command to:

```
npm install
npm start
```

Once deployed, use the live URL in your GPT Custom Builder under OpenAPI schema.